// // app.js
// const express = require('express');
// const bodyParser = require('body-parser');
// const sqlite3 = require('sqlite3').verbose();

// const app = express();
// const port = 3000;

// // Connect to SQLite database
// const db = new sqlite3.Database('employees.db');

// // Create a table to store employee data
// db.run(`CREATE TABLE IF NOT EXISTS employees (
//     id INTEGER PRIMARY KEY AUTOINCREMENT,
//     name TEXT,
//     position TEXT
// );`);

// // Middleware to parse the request body
// app.use(bodyParser.urlencoded({ extended: true }));

// // Serve static files (e.g., HTML, CSS)
// app.use(express.static('public'));

// // Define route for submitting employee data
// app.post('/submit', (req, res) => {
//     const { name, position } = req.body;

//     // Insert data into the database
//     db.run('INSERT INTO employees (name, position) VALUES (?, ?)', [name, position], function (err) {
//         if (err) {
//             return res.status(500).send('Internal Server Error');
//         }
//         const newEmployeeId = this.lastID;
//         console.log(`A new employee has been added with ID ${newEmployeeId}`);
//         res.send(`Data received and saved to the database! Employee ID: ${newEmployeeId}`);
//     });
// });

// // Start the server
// app.listen(port, () => {
//     console.log(`Server listening at http://localhost:${port}`);
// });








// app.js
const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const port = 3000;

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Connect to SQLite database
const db = new sqlite3.Database('employees.db');

// Create a table to store employee data
db.run(`CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    position TEXT
);`);

// Middleware to parse the request body
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files (e.g., HTML, CSS)
app.use(express.static('public'));

// Define route for submitting employee data
app.post('/submit', (req, res) => {
    const { name, position } = req.body;

    // Insert data into the database
    db.run('INSERT INTO employees (name, position) VALUES (?, ?)', [name, position], function (err) {
        if (err) {
            return res.status(500).send('Internal Server Error');
        }
        const newEmployeeId = this.lastID;
        console.log(`A new employee has been added with ID ${newEmployeeId}`);
        res.send(`Data received and saved to the database! Employee ID: ${newEmployeeId}`);
    });
});

// Define route for viewing employee data
app.get('/view', (req, res) => {
    // Query the database for all employees
    db.all('SELECT * FROM employees', (err, rows) => {
        if (err) {
            return res.status(500).send('Internal Server Error');
        }
        // Render the view.html page and pass the data to it
        res.render('view', { employees: rows });
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});
