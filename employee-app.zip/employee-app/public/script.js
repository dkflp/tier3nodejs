// script.js
document.addEventListener('DOMContentLoaded', function () {
    const employeeForm = document.getElementById('employeeForm');

    employeeForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Get form data
        const formData = new FormData(employeeForm);
        const formDataObject = {};
        formData.forEach((value, key) => {
            formDataObject[key] = value;
        });

        // Send a POST request to the server
        fetch('/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formDataObject),
        })
            .then(response => response.text())
            .then(data => {
                console.log(data);
                alert('Data submitted successfully!');
                // You can redirect or perform any other action after successful submission.
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
    });
});
